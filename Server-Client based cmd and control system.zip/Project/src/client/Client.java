
package client;
/**
 *
 * @author Arghya Dasgupta
 */
public class Client {
    public static void main(String[] args) {
        Cframe c=new Cframe();
        c.setVisible(true);
    }
    
}
