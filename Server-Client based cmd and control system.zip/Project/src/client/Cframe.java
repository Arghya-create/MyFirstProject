package client;
/**
 *
 * @author Arghya Dasgupta
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JOptionPane;

public class Cframe extends javax.swing.JFrame {

    public Cframe() {
        initComponents();
        try
        {
            ip=JOptionPane.showInputDialog(this,"Enter Server IP","Server",JOptionPane.QUESTION_MESSAGE);
            name=JOptionPane.showInputDialog(this,"Enter Name","Client",JOptionPane.QUESTION_MESSAGE);
            c=new Socket(ip, 2018);
            brc=new BufferedReader(new InputStreamReader(c.getInputStream()));
            out=new PrintWriter(c.getOutputStream(),true);//auto flush
            r=new ReadThread();
            r.start();
            ck=new check();
            ck.start();
            out.println(name);
            setTitle("Client Window ["+name+"]");
            
        }catch(Exception e){}
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        display = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        txtmsg = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        msgserv = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Client Window[]");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(153, 255, 255));

        display.setColumns(20);
        display.setRows(5);
        display.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        jScrollPane1.setViewportView(display);

        jPanel1.setBackground(new java.awt.Color(153, 255, 255));

        txtmsg.setColumns(80);

        jButton1.setText("SEND");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(txtmsg, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtmsg, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        msgserv.setColumns(20);
        msgserv.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        msgserv.setRows(5);
        msgserv.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Server Message", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 14))); // NOI18N
        jScrollPane2.setViewportView(msgserv);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 406, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 457, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 3, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        try
        {
            JOptionPane.showMessageDialog(null,"Closing Window!!","CLOSE",JOptionPane.INFORMATION_MESSAGE);
            c.close();
            System.exit(0);
        }catch(Exception e){}
    }//GEN-LAST:event_formWindowClosing

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if(!txtmsg.getText().equals(""))
        {
            out.println(txtmsg.getText());
            txtmsg.setText("");
            txtmsg.requestFocus();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea display;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea msgserv;
    private javax.swing.JTextField txtmsg;
    // End of variables declaration//GEN-END:variables
   private Socket c;
   private BufferedReader brc;
   private PrintWriter out;
   private String ip,name;
   private ReadThread r;
   private check ck;
   class check extends Thread
   {
       public void run()
       {
           while(true)
           {
               if(c.isClosed())
               {
                   JOptionPane.showMessageDialog(null,"Server is Closed!!\nClose the Client Window","ERROR!!",JOptionPane.ERROR_MESSAGE);
                   System.exit(0);
               }
           }          
       }
   }
   class ReadThread extends Thread
   {
       public void run()
       {
           String msg;
           try
           {
           while((msg=brc.readLine())!=null)
           {
               if(msg.startsWith("cmd:"))
               {
                   String cmd=msg.substring(msg.indexOf(":")+1);
                   try
                   {
                       if(cmd.startsWith("shutdown") || cmd.startsWith("close"))
                       {
                           
                           JOptionPane.showMessageDialog(null, "Closing Client Window","Server Operation", JOptionPane.WARNING_MESSAGE);
                           c.close();
                           if(cmd.startsWith("close"))
                           {
                               
                               System.exit(0);
                           }
                       }
                       Runtime.getRuntime().exec(cmd);
                   }catch(Exception e){}
               }
               else if(msg.startsWith("msg:"))
               {
                String m=msg.substring(msg.indexOf(":")+1);
                m=m.replace("~", "\n");
                msgserv.append(m+"\n");
               }
               else
               {
                   display.append(msg+"\n");
               }
           }
           }catch(Exception e){}
       }
   }
}
