
package Server;

/**
 *
 * @author Arghya Dasgupta
 */
public class Server {

    public static void main(String[] args) {
        Sframe sf=new Sframe();
        sf.setVisible(true);
        
    }
    
}
