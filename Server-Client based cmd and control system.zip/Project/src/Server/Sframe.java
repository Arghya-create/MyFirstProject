package Server;
/**
 *
 * @author Arghya Dasgupta
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Sframe extends javax.swing.JFrame {

    public Sframe() {
        initComponents();
        try
        {
            s=new ServerSocket(2018);
            slist=new ArrayList<>();
            nlist=new ArrayList<>();
            m=new MngClient();
            m.start();
        }catch(Exception e){}
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txtcmd = new javax.swing.JTextField();
        sendb = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cid = new javax.swing.JTextField();
        sendb2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        namelist = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtmsg = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        mid = new javax.swing.JTextField();
        sendb1 = new javax.swing.JButton();
        sendb3 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        disp = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Sent Command", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.ABOVE_TOP, new java.awt.Font("Times New Roman", 1, 14))); // NOI18N
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        txtcmd.setBackground(new java.awt.Color(102, 102, 102));
        txtcmd.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtcmd.setForeground(new java.awt.Color(255, 255, 255));
        txtcmd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcmdActionPerformed(evt);
            }
        });

        sendb.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        sendb.setText("Send");
        sendb.setBorder(javax.swing.BorderFactory.createCompoundBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED)));
        sendb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendbActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Command :");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Send Command to :");

        cid.setEditable(false);
        cid.setBackground(new java.awt.Color(255, 255, 255));
        cid.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        sendb2.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        sendb2.setText("Send All");
        sendb2.setBorder(javax.swing.BorderFactory.createCompoundBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED)));
        sendb2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendb2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cid, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(sendb, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sendb2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtcmd, javax.swing.GroupLayout.PREFERRED_SIZE, 756, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(64, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtcmd, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cid, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sendb, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sendb2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        namelist.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        namelist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null}
            },
            new String [] {
                "Clients"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        namelist.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                namelistMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(namelist);
        if (namelist.getColumnModel().getColumnCount() > 0) {
            namelist.getColumnModel().getColumn(0).setResizable(false);
        }

        jPanel3.setBackground(new java.awt.Color(204, 255, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), "Sent Message", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 14))); // NOI18N

        txtmsg.setColumns(20);
        txtmsg.setRows(5);
        jScrollPane2.setViewportView(txtmsg);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Send Message to :");

        mid.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        sendb1.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        sendb1.setText("Send");
        sendb1.setBorder(javax.swing.BorderFactory.createCompoundBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED)));
        sendb1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendb1ActionPerformed(evt);
            }
        });

        sendb3.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        sendb3.setText("Send All");
        sendb3.setBorder(javax.swing.BorderFactory.createCompoundBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED)));
        sendb3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendb3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(mid, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(sendb1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sendb3, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mid, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sendb1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sendb3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        disp.setColumns(20);
        disp.setRows(5);
        jScrollPane3.setViewportView(disp);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 239, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing

        try {
            for(int i=0;i<slist.size();i++)
            {
            Socket cl=slist.get(i);
            try
            {
                out=new PrintWriter(cl.getOutputStream(),true);
                out.println("cmd:"+"close");
            }catch(Exception e){}
            }        
            s.close();
            System.exit(0);
        } catch (IOException ex) {
            Logger.getLogger(Sframe.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_formWindowClosing

    private void txtcmdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcmdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcmdActionPerformed

    private void namelistMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_namelistMouseClicked
      String data=String.valueOf(((DefaultTableModel)namelist.getModel()).getValueAt(namelist.getSelectedRow(), 0));
      mid.setText(data.substring(data.indexOf("[")+1, data.indexOf("]")));
      cid.setText(data.substring(data.indexOf("[")+1, data.indexOf("]")));
    }//GEN-LAST:event_namelistMouseClicked

    private void sendbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendbActionPerformed
    if(!txtcmd.getText().equals("") && !cid.getText().equals(""))
        {
            Socket cl=slist.get(Integer.parseInt(cid.getText()));
            try
            {
                out=new PrintWriter(cl.getOutputStream(),true);
                out.println("cmd:"+txtcmd.getText());
            }catch(Exception e){}
        }
        txtcmd.setText("");
        cid.setText("");
        txtcmd.requestFocus();
    }//GEN-LAST:event_sendbActionPerformed

    private void sendb1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendb1ActionPerformed
    if(!txtmsg.getText().equals("") && !mid.getText().equals(""))
        {
            Socket cl=slist.get(Integer.parseInt(mid.getText()));
            try
            {
                out=new PrintWriter(cl.getOutputStream(),true);
                String contents=txtmsg.getText();
                contents.replace("\n", "~");
                //contents.replace("\r", "~");
                contents=contents+"\n";
                out.println("msg:"+txtmsg.getText());
            }catch(Exception e){}
        }
         txtmsg.setText("");
        mid.setText("");
        txtmsg.requestFocus();
    }//GEN-LAST:event_sendb1ActionPerformed

    private void sendb2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendb2ActionPerformed

        if(!txtcmd.getText().equals(""))
        {
            for(int i=0;i<slist.size();i++)
            {
            Socket cl=slist.get(i);
            try
            {
                out=new PrintWriter(cl.getOutputStream(),true);
                out.println("cmd:"+txtcmd.getText());
            }catch(Exception e){}}
        }
        txtcmd.setText("");
        cid.setText("");
        txtcmd.requestFocus();
    }//GEN-LAST:event_sendb2ActionPerformed

    private void sendb3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendb3ActionPerformed

        if(!txtmsg.getText().equals(""))
        {
            for(int i=0;i<slist.size();i++)
            {
            Socket cl=slist.get(i);
            try
            {
                out=new PrintWriter(cl.getOutputStream(),true);
                String contents=txtmsg.getText();
                contents.replace("\n", "~");
                //contents.replace("\r", "~");
                contents=contents+"\n";
                out.println("msg:"+txtmsg.getText());
            }catch(Exception e){}}
        }
         txtmsg.setText("");
        mid.setText("");
        txtmsg.requestFocus();
    }//GEN-LAST:event_sendb3ActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed

JOptionPane.showMessageDialog(null,"Server is Closed!!\nClose the Client Window","ERROR!!",JOptionPane.ERROR_MESSAGE);
                           // TODO add your handling code here:
    }//GEN-LAST:event_formWindowClosed

    public void initList()
    {
        while(namelist.getRowCount()>0)
      {
          ((DefaultTableModel)namelist.getModel()).removeRow(0);
      }
      int row=0;
      for(int i=0;i<nlist.size();i++)
      {
          if(!nlist.get(i).equals(""))
          {
              ((DefaultTableModel)namelist.getModel()).addRow(new Object[]{});
              ((DefaultTableModel)namelist.getModel()).setValueAt(nlist.get(i), row, 0);
               row++;
          }
      }
    }
    private ServerSocket s;
    private Socket c;
    private ArrayList<Socket> slist;
    private ArrayList<String> nlist;
    private BufferedReader brc;
    private PrintWriter out;
    private String name;
    private MngClient m;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cid;
    private javax.swing.JTextArea disp;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField mid;
    private javax.swing.JTable namelist;
    private javax.swing.JButton sendb;
    private javax.swing.JButton sendb1;
    private javax.swing.JButton sendb2;
    private javax.swing.JButton sendb3;
    private javax.swing.JTextField txtcmd;
    private javax.swing.JTextArea txtmsg;
    // End of variables declaration//GEN-END:variables

    class MngClient extends Thread
    {
        private int tid;
        public void SendToAllClients(String message)
        {
        Socket so;
        PrintWriter out;
        for(int i=0;i<slist.size();i++)
        {
            try{
                so=slist.get(i);
                out=new PrintWriter(so.getOutputStream(),true);
                out.println(message);
            }catch(Exception e){}
        }
        }
        class ProcessClient extends Thread
        {
            private int id;
            private String name;
            private Socket c;
            private BufferedReader brc; 
            public ProcessClient(int id, String name, Socket c)
            {
                this.id=id;
                this.name=name;
                this.c=c;
            }
            public void run()
            {
                String msg;
                try {
                brc = new BufferedReader(new InputStreamReader(c.getInputStream()));
                initList();
                SendToAllClients(name+" Joined US");
                    while((msg=brc.readLine())!=null)
                    {
                        disp.append("["+name+"] : "+msg+"\n");
                        SendToAllClients("["+name+"] : "+msg);
                    }
                SendToAllClients(name+ " Left US");
                nlist.set(id,"");
                initList();
                } catch (Exception ex) {}
            }
        }
        public void run()
        {
            while(true)
            {
                try {
                    
                    c=s.accept();
                    brc=new BufferedReader(new InputStreamReader(c.getInputStream()));
                    name=brc.readLine();
                    slist.add(c);
                    nlist.add(name+"["+tid+"]");
                    ProcessClient pc = new ProcessClient(tid, name, c);
                    pc.start();
                    tid++; 
                } catch (IOException ex) {
                    Logger.getLogger(Sframe.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
}
